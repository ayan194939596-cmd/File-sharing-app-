package com.fileshare.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;

/** FileShare: send files to, or receive files from, another device on the same Wi-Fi. */
public class MainActivity extends Activity {
    static final int PICK = 1, WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    // Page served to browsers so a computer can send files to this phone too.
    static final String PAGE = "<!doctype html><meta name='viewport' content='width=device-width,initial-scale=1'>"
            + "<body style='font-family:sans-serif;padding:20px'><h2>Send files to this phone</h2>"
            + "<input type='file' id='f' multiple><p><button onclick='go()'>Send</button></p><div id='o'></div>"
            + "<script>async function go(){const o=document.getElementById('o');"
            + "for(const x of document.getElementById('f').files){o.append(x.name+' ... ');"
            + "try{const r=await fetch('/u?n='+encodeURIComponent(x.name),{method:'PUT',body:x});"
            + "o.append(r.ok?'done':'failed',document.createElement('br'))}"
            + "catch(e){o.append('failed',document.createElement('br'))}}}</script>";

    final List<Uri> picked = new ArrayList<>();
    ServerSocket server;
    LinearLayout sendPanel, recvPanel;
    TextView picks, addr, log;
    EditText target;
    CheckBox zip;
    ProgressBar bar;
    Button start, sendBtn;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(40), dp(20), dp(20));
        sv.addView(root);

        TextView title = text("FileShare", 30, true);
        title.setTextColor(0xFF0B57D0);
        root.addView(title);
        root.addView(text("Send and receive files over Wi-Fi. Both phones need the same Wi-Fi or hotspot, and this screen open.", 14, false));

        LinearLayout tabs = new LinearLayout(this);
        Button tSend = new Button(this), tRecv = new Button(this);
        tSend.setText("Send");
        tRecv.setText("Receive");
        tabs.addView(tSend, new LinearLayout.LayoutParams(0, WRAP, 1));
        tabs.addView(tRecv, new LinearLayout.LayoutParams(0, WRAP, 1));
        root.addView(tabs);

        sendPanel = panel(root);
        Button choose = new Button(this);
        choose.setText("Choose files");
        picks = text("No files chosen", 14, false);
        target = new EditText(this);
        target.setHint("Receiver address, e.g. 192.168.1.5:8080");
        target.setSingleLine(true);
        zip = new CheckBox(this);
        zip.setText("Zip files into one before sending");
        sendBtn = new Button(this);
        sendBtn.setText("Send now");
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        sendPanel.addView(choose);
        sendPanel.addView(picks);
        sendPanel.addView(target);
        sendPanel.addView(zip);
        sendPanel.addView(sendBtn);
        sendPanel.addView(bar);

        recvPanel = panel(root);
        start = new Button(this);
        start.setText("Start receiving");
        addr = text("Tap Start receiving, then type the address shown here on the sending phone.", 16, false);
        addr.setTypeface(Typeface.MONOSPACE);
        recvPanel.addView(start);
        recvPanel.addView(addr);
        recvPanel.addView(text("Files are saved in Downloads/FileShare. A computer can also open the address in a browser to send files here.", 13, false));
        recvPanel.setVisibility(View.GONE);

        log = text("", 14, false);
        root.addView(log);
        setContentView(sv);

        tSend.setOnClickListener(v -> {
            sendPanel.setVisibility(View.VISIBLE);
            recvPanel.setVisibility(View.GONE);
        });
        tRecv.setOnClickListener(v -> {
            sendPanel.setVisibility(View.GONE);
            recvPanel.setVisibility(View.VISIBLE);
        });
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, PICK);
        });
        sendBtn.setOnClickListener(v -> send());
        start.setOnClickListener(v -> toggleServer());
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req != PICK || res != RESULT_OK || d == null) return;
        picked.clear();
        if (d.getClipData() != null) {
            for (int i = 0; i < d.getClipData().getItemCount(); i++) {
                picked.add(d.getClipData().getItemAt(i).getUri());
            }
        } else if (d.getData() != null) {
            picked.add(d.getData());
        }
        picks.setText(picked.size() + " file(s) chosen");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopServer();
    }

    // ---------- Receive ----------

    void toggleServer() {
        if (server != null) {
            stopServer();
            return;
        }
        try {
            try {
                server = new ServerSocket(8080);
            } catch (IOException e) {
                server = new ServerSocket(0);
            }
        } catch (IOException e) {
            say("Could not start receiving: " + msg(e));
            return;
        }
        final ServerSocket ss = server;
        addr.setText(localIp() + ":" + ss.getLocalPort());
        start.setText("Stop receiving");
        say("Waiting for files. Type the address above on the sending phone.");
        new Thread(() -> {
            while (!ss.isClosed()) {
                try {
                    final Socket s = ss.accept();
                    new Thread(() -> handle(s)).start();
                } catch (IOException e) {
                    break;
                }
            }
        }).start();
    }

    void stopServer() {
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        server = null;
        if (start != null) start.setText("Start receiving");
        if (addr != null) addr.setText("Receiving stopped.");
    }

    void handle(Socket s) {
        Uri out = null;
        try (Socket sock = s) {
            sock.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(sock.getInputStream(), 65536);
            String req = line(in);
            if (req == null) return;
            long len = 0;
            String h;
            while ((h = line(in)) != null && !h.isEmpty()) {
                if (h.toLowerCase(Locale.ROOT).startsWith("content-length:")) {
                    len = Long.parseLong(h.substring(15).trim());
                }
            }
            if (req.startsWith("GET / ")) {
                reply(sock, 200, "text/html", PAGE);
                return;
            }
            if (!req.startsWith("PUT /u?n=")) {
                reply(sock, 404, "text/plain", "Not found");
                return;
            }
            String name = clean(URLDecoder.decode(req.substring(9, req.lastIndexOf(' ')), "UTF-8"));

            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download/FileShare");
            out = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (out == null) throw new IOException("Cannot create the file in Downloads");
            try (OutputStream o = getContentResolver().openOutputStream(out)) {
                byte[] buf = new byte[65536];
                long left = len;
                while (left > 0) {
                    int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n < 0) throw new EOFException("Connection lost");
                    o.write(buf, 0, n);
                    left -= n;
                }
            }
            out = null; // finished: keep the file
            reply(sock, 200, "text/plain", "OK");
            say("Received: " + name + "\nSaved in Downloads/FileShare");
        } catch (Exception e) {
            if (out != null) {
                try {
                    getContentResolver().delete(out, null, null);
                } catch (Exception ignored) {
                }
            }
            say("Receiving failed: " + msg(e));
        }
    }

    static String line(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1 && c != '\n') {
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 8192) throw new IOException("Header too long");
        }
        return (c == -1 && sb.length() == 0) ? null : sb.toString();
    }

    static void reply(Socket s, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes("UTF-8");
        OutputStream o = s.getOutputStream();
        o.write(("HTTP/1.1 " + code + (code == 200 ? " OK" : " Error")
                + "\r\nContent-Type: " + type + "; charset=utf-8\r\nContent-Length: " + b.length
                + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
        o.write(b);
        o.flush();
    }

    static String clean(String n) {
        n = n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (n.length() > 120) n = n.substring(n.length() - 120);
        return n.isEmpty() ? "file" : n;
    }

    String localIp() {
        try {
            for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(n.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return "(connect to Wi-Fi first)";
    }

    // ---------- Send ----------

    void send() {
        if (picked.isEmpty()) {
            say("Choose at least one file first.");
            return;
        }
        String a = target.getText().toString().trim().replace("http://", "");
        if (a.endsWith("/")) a = a.substring(0, a.length() - 1);
        if (a.isEmpty()) {
            say("Type the receiver's address first. It is shown on the receiving phone.");
            return;
        }
        String host = a;
        int port = 8080;
        int c = a.lastIndexOf(':');
        if (c > 0) {
            host = a.substring(0, c);
            try {
                port = Integer.parseInt(a.substring(c + 1));
            } catch (NumberFormatException e) {
                say("The port after ':' must be a number.");
                return;
            }
        }
        final String h = host;
        final int p = port;
        final boolean asZip = zip.isChecked();
        final List<Uri> files = new ArrayList<>(picked);
        sendBtn.setEnabled(false);

        new Thread(() -> {
            File tmp = null;
            try {
                if (asZip) {
                    say("Zipping files...");
                    tmp = new File(getCacheDir(), "FileShare.zip");
                    zipTo(tmp, files);
                    say("Sending FileShare.zip ...");
                    push(h, p, "FileShare.zip", tmp.length(), new FileInputStream(tmp));
                } else {
                    int k = 0;
                    for (Uri u : files) {
                        String nm = nameOf(u);
                        say("Sending " + (++k) + " of " + files.size() + ": " + nm);
                        long sz = sizeOf(u);
                        if (sz < 0) { // size unknown: copy to cache first to learn it
                            tmp = new File(getCacheDir(), "stage.tmp");
                            try (InputStream i = open(u); OutputStream o = new FileOutputStream(tmp)) {
                                copy(i, o);
                            }
                            push(h, p, nm, tmp.length(), new FileInputStream(tmp));
                        } else {
                            push(h, p, nm, sz, open(u));
                        }
                    }
                }
                say("Done. Sent " + (asZip ? "1 zip file" : files.size() + " file(s)") + ".");
            } catch (Exception e) {
                say("Sending failed: " + msg(e) + "\nCheck the address, and that the other phone shows 'Stop receiving'.");
            } finally {
                if (tmp != null) tmp.delete();
                runOnUiThread(() -> {
                    sendBtn.setEnabled(true);
                    bar.setProgress(0);
                });
            }
        }).start();
    }

    void push(String host, int port, String name, long size, InputStream src) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(
                "http://" + host + ":" + port + "/u?n=" + URLEncoder.encode(name, "UTF-8")).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(60000);
        c.setRequestMethod("PUT");
        c.setRequestProperty("Connection", "close");
        c.setDoOutput(true);
        c.setFixedLengthStreamingMode(size);
        try (OutputStream o = c.getOutputStream(); InputStream i = src) {
            byte[] buf = new byte[65536];
            long sent = 0;
            int n, last = -1;
            while ((n = i.read(buf)) != -1) {
                o.write(buf, 0, n);
                sent += n;
                final int pct = size > 0 ? (int) (sent * 100 / size) : 100;
                if (pct != last) {
                    last = pct;
                    runOnUiThread(() -> bar.setProgress(pct));
                }
            }
        }
        int code = c.getResponseCode();
        c.disconnect();
        if (code != 200) throw new IOException("Receiver replied with code " + code);
    }

    void zipTo(File dest, List<Uri> files) throws IOException {
        Set<String> used = new HashSet<>();
        try (ZipOutputStream zo = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(dest)))) {
            for (Uri u : files) {
                String n = clean(nameOf(u));
                for (int i = 1; !used.add(n); i++) n = i + "_" + clean(nameOf(u));
                zo.putNextEntry(new ZipEntry(n));
                try (InputStream in = open(u)) {
                    copy(in, zo);
                }
                zo.closeEntry();
            }
        }
    }

    InputStream open(Uri u) throws IOException {
        InputStream s = getContentResolver().openInputStream(u);
        if (s == null) throw new FileNotFoundException("Cannot open the chosen file");
        return s;
    }

    long sizeOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception ignored) {
        }
        return -1;
    }

    String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getString(0);
        } catch (Exception ignored) {
        }
        String p = u.getLastPathSegment();
        return p == null ? "file" : p;
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[65536];
        int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
    }

    // ---------- UI helpers ----------

    static String msg(Exception e) {
        return e.getMessage() != null ? e.getMessage() : e.toString();
    }

    void say(String s) {
        runOnUiThread(() -> log.setText(s));
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(8), 0, dp(8));
        return t;
    }

    LinearLayout panel(LinearLayout root) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        root.addView(l);
        return l;
    }
}
